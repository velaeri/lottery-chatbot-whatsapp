# 🎯 Lottery Chatbot Backend

Backend del chatbot de lotería con DeepSeek AI y Supabase.

## 🚀 Despliegue en Railway

### Paso 1: Crear cuenta en Railway
1. Ve a [railway.app](https://railway.app)
2. Regístrate con GitHub (gratis)

### Paso 2: Desplegar desde GitHub
1. Sube este código a un repositorio de GitHub
2. En Railway, haz clic en "New Project"
3. Selecciona "Deploy from GitHub repo"
4. Conecta tu repositorio

### Paso 3: Configurar variables de entorno
En Railway, ve a Variables y añade:
```
SUPABASE_URL=https://zgttgbdbujrzduqekfmp.supabase.co
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpndHRnYmRidWpyemR1cWVrZm1wIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1Nzk3MzIwMywiZXhwIjoyMDczNTQ5MjAzfQ.bL6YhyLDKmwTfXwYazE1VvuxREhnf8KYDwY5D0nJvbw
DEEPSEEK_API_KEY=sk-86c5897b82cc4daca828dd989ba03349
```

### Paso 4: ¡Listo!
Railway te dará una URL como: `https://tu-proyecto.railway.app`

## 📡 Endpoints

- `GET /` - Información de la API
- `GET /health` - Estado de salud
- `POST /chat` - Chat principal
- `POST /chat/stream` - Chat con streaming
- `GET /stats` - Estadísticas de billetes

## 🎯 Funcionalidades

- ✅ DeepSeek AI integrado
- ✅ Base de datos real en Supabase
- ✅ Consulta de billetes dinámicos
- ✅ Sistema de compras completo
- ✅ Streaming de respuestas
- ✅ CORS configurado para frontend

## 🔧 Desarrollo local

```bash
npm install
npm start
```

El servidor se ejecutará en `http://localhost:3000`

